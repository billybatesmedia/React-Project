import React from 'react';
// this impots react
import ReactDOM  from 'react-dom/client';
//this connects react connects it to the DOM 


// this is a function  "const" creates the  "App" which is the name of the app.

const App = () => {
   return React.createElement('h1', {className:'title'}, 'hello world!' )
}
// this calls the function,  and and the host div="root" 
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
